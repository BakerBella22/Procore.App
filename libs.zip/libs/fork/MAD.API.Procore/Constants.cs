﻿namespace MAD.API.Procore
{
    public static class Constants
    {
        public const int MaxResultsPerPage = 1000;
    }
}
